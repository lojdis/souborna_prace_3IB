fun main() {
    val card = generateCard()

    println("Vítejte ve hře Bingo!")
    println("Hrací pole:")
    printCard(card)

    val userNumbers = inputUserNumbers()

    val result = checkBingo(card, userNumbers)

    if (result) {
        println("Gratulujeme! Získali jste Bingo!")
    } else {
        println("Bohužel, nemáte Bingo. Zkuste to příště.")
    }
}

fun generateCard(): List<List<Int>> = List(6) { List(6) { (0..99).random() } }

fun printCard(card: List<List<Int>>) = card.forEach { row -> println(row.joinToString("\t")) }

fun inputUserNumbers(): List<Int> {
    println("Zadejte 6 až 12 čísel od 0 do 99 (oddělte je mezerou):")
    return readLine()?.split(" ")?.mapNotNull { it.toIntOrNull() }?.takeIf { it.size in 6..12 && it.all { it in 0..99 } }
        ?: run {
            println("Napsal jste toho hodně nebo málo. Zadejte prosím 6 až 12 čísel od 0 do 99.")
            inputUserNumbers()
        }
}

fun checkBingo(card: List<List<Int>>, userNumbers: List<Int>): Boolean = userNumbers.all { it in card.flatten() }